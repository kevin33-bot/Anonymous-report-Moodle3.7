pChart 2.0 library for PHP 7
===================

The good old pChart got an overhaul

 - All examples work fine with zero code modifications to them
 - Code was beautified
 - Made some minor improvements and added some speed ups
 
