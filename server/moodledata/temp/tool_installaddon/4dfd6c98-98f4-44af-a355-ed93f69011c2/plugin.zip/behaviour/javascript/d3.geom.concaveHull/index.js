var d3 = require('d3');

d3.layout.concaveHull = require('./src/concaveHull');

module.exports = d3;